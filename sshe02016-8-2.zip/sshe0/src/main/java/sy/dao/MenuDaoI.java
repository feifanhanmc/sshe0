package sy.dao;

import sy.model.Tmenu;

public interface MenuDaoI extends BaseDaoI<Tmenu>
{

}
