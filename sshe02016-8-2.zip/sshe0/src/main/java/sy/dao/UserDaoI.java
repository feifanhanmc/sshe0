package sy.dao;

import sy.model.Muser;

public interface UserDaoI extends BaseDaoI<Muser>
{

}
